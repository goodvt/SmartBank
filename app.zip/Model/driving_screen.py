from Model.base_model import BaseScreenModel


class DrivingScreenModel(BaseScreenModel):
    """
    Implements the logic of the
    :class:`~View.driving_screen.DrivingScreen.DrivingScreenView` class.
    """