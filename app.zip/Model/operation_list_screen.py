from Model.base_model import BaseScreenModel


class OperationListScreenModel(BaseScreenModel):
    """
    Implements the logic of the
    :class:`~View.operation_list_screen.OperationListScreen.OperationListScreenView` class.
    """