from Model.base_model import BaseScreenModel


class SampleScreenModel(BaseScreenModel):
    """
    Implements the logic of the
    :class:`~View.sample_screen.SampleScreen.SampleScreenView` class.
    """