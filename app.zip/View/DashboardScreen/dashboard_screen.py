from View.base_screen import BaseScreenView


class DashboardScreenView(BaseScreenView):
    def __init__(self, *args, **kwargs):
        super(DashboardScreenView, self).__init__(*args, **kwargs)
